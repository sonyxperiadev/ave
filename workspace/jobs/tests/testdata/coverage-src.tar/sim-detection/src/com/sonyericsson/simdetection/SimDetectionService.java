/*
 * Copyright (c) 2012-2013 Sony Mobile Communications AB.
 * All rights, including trade secret rights, reserved.
 */
package com.sonyericsson.simdetection;

import android.app.AlertDialog;
import android.app.Notification;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.PowerManager;
import android.util.Log;
import android.view.WindowManager;

public class SimDetectionService extends Service {
    private static final String TAG = "SimDetectionService";

    private static final String REBOOT_REASON = "Reboot for Sim inserted/removed";

    private static final int SIM_STATE_CHANGED = 0x0001;

    private static final int RESTART_PHONE = 0x0002;

    private static final int SIM_CARD_REMOVED = 0;

    private static final int SIM_CARD_INSERTED = 1;

    // A flag to determine if we are running a unittest
    private static boolean mIsUnitTesting = false;

    private boolean mIsStarted = false;

    private Context mContext = null;

    private AlertDialog mRestartDlg = null;

    private Handler mHandler = new Handler() {
        public void handleMessage(Message msg) {
            Log.i(TAG, "handleMessage " + msg.what);
            switch (msg.what) {
                case SIM_STATE_CHANGED:
                    processSimCardOperation(msg.arg1);
                    break;
                case RESTART_PHONE:
                    processRestartPhone();
                    break;
                default:
                    break;
            }
            removeMessages(msg.what);
        }
    };

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        mContext = getApplicationContext();
    }

    public int onStartCommand(Intent intent, int flags, int startId) {
        if (null == intent) {
            return START_NOT_STICKY;
        } else if (SimDetectionIntent.SIMCARD_STATE_CHANGED.equals(intent.getAction())) {
            if (!mIsStarted) {
                mIsStarted = true;
                if (!mIsUnitTesting) {
                    // Empty icon with no text is displayed when application
                    // is started in foreground
                    Intent notificationIntent = new Intent(this, SimDetectionService.class);

                    PendingIntent pendingIntent = PendingIntent.getActivity(this, 0,
                            notificationIntent, 0);
                    Notification notification = new Notification.Builder(this).
                            setContentTitle("").
                            setContentText("").
                            setSmallIcon(R.drawable.icon_empty).
                            setTicker("").
                            setContentIntent(pendingIntent).
                            getNotification();
                    startForeground(10, notification);
                }
            }
            boolean simPresent = intent.getBooleanExtra(SimDetectionIntent.EXTRA_SIMCARD_PRESENT,
                    false);
            boolean systemReady = intent.getBooleanExtra(
                    SimDetectionIntent.EXTRA_DEVICE_BOOT_COMPLETED, true);
            Message msg = mHandler.obtainMessage(RESTART_PHONE);
            if (systemReady) {
                msg = mHandler.obtainMessage(SIM_STATE_CHANGED);
                msg.arg1 = simPresent ? SIM_CARD_INSERTED : SIM_CARD_REMOVED;
            }
            mHandler.sendMessage(msg);
        } else if (!mIsStarted && Intent.ACTION_SHUTDOWN.equals(intent.getAction())) {
            mIsStarted = true;
        }
        return START_NOT_STICKY;
    }

    /**
     * Process sim card insert/remove operation
     *
     * 1. If invalid simCardState, return directly.
     * 2. Show a restart dialog.
     *
     * @param simCardState 0 show dialog of sim card removed
     *                     1 show dialog of sim card inserted
     */
    private void processSimCardOperation(int simCardState) {
        Log.i(TAG, "processSimCardOperation " + simCardState);
        if ((SIM_CARD_REMOVED == simCardState) || (SIM_CARD_INSERTED == simCardState)) {
            int resIdTitleText;
            int resIdBodyText;
            if (SIM_CARD_REMOVED == simCardState) {
                resIdTitleText = R.string.SIM_detection_alert_dlg_extract_title_txt;
                resIdBodyText = R.string.SIM_detection_alert_dlg_extract_description_txt;
            } else {
                resIdTitleText = R.string.SIM_detection_alert_dlg_insert_title_txt;
                resIdBodyText = R.string.SIM_detection_alert_dlg_insert_description_txt;
            }
            CharSequence title = mContext.getText(resIdTitleText);
            CharSequence body = mContext.getText(resIdBodyText);
            if (null == mRestartDlg) {
                AlertDialog.Builder builder =
                        new AlertDialog.Builder(mContext, AlertDialog.THEME_DEVICE_DEFAULT_DARK);
                builder.setTitle(title)
                       .setMessage(body)
                       .setCancelable(false)
                       .setPositiveButton(R.string.SIM_detection_alert_dlg_button_txt,
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    // send a message to restart the phone on user acknowledge
                                    Message msg = mHandler.obtainMessage(RESTART_PHONE);
                                    mHandler.sendMessage(msg);
                                }
                            });
                mRestartDlg = builder.create();
                mRestartDlg.setCanceledOnTouchOutside(false);

                if (null != mRestartDlg.getWindow()) {
                    mRestartDlg.getWindow()
                            .setType(WindowManager.LayoutParams.TYPE_BOOT_PROGRESS);
                }
                mRestartDlg.show();
            } else {
                mRestartDlg.setTitle(title);
                mRestartDlg.setMessage(body);
            }
        }
    }

    private void processRestartPhone() {
        if ((null != mRestartDlg) && mRestartDlg.isShowing()) {
            mRestartDlg.dismiss();
        }

        new Thread(new Runnable() {
            public void run() {
                PowerManager pm = (PowerManager)mContext.getSystemService(Context.POWER_SERVICE);
                pm.reboot(REBOOT_REASON);
            }
        }).start();
    }
}

/*
 * Copyright 2011 Sony Ericsson Mobile Communications AB.
 * Copyright (C) 2012 Sony Mobile Communications AB.
 * All rights, including trade secret rights, reserved.
 */

package com.sonyericsson.simdetection;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.PowerManager;

/**
 * Receiver for Sim card remove/insert
 */
public class SimDetectionReceiver extends BroadcastReceiver {

	private static final long TIMEOUT = 5 * 1000;// 5 seconds

    @Override
    public void onReceive(Context context, Intent intent) {
        if (null != context && null != intent) {
            final String action = intent.getAction();
            if (SimDetectionIntent.SIMCARD_STATE_CHANGED.equals(action) ||
                    Intent.ACTION_SHUTDOWN.equals(action)) {
                Intent serviceIntent = new Intent(context, SimDetectionService.class);
                serviceIntent.setAction(action);
                serviceIntent.putExtras(intent);
                pokeWakeLock(context);
                context.startService(serviceIntent);
            }
        }
    }

    private void pokeWakeLock(Context context) {
        PowerManager pm = (PowerManager)context.getSystemService(Context.POWER_SERVICE);
        PowerManager.WakeLock screenWakeLock = pm.newWakeLock(PowerManager.ACQUIRE_CAUSES_WAKEUP
                | PowerManager.SCREEN_BRIGHT_WAKE_LOCK, "turn on screen");
        screenWakeLock.setReferenceCounted(false);
        screenWakeLock.acquire(TIMEOUT);
    }
}
